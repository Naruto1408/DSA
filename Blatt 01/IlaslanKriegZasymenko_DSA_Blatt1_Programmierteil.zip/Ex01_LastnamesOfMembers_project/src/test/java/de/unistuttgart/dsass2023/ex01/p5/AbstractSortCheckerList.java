// SOLUTION
package de.unistuttgart.dsass2023.ex01.p5;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import de.unistuttgart.dsass2023.ex01.p5.ISimpleList;

public abstract class AbstractSortCheckerList<T extends Comparable<T>> implements ISimpleList<T> {
	

}
