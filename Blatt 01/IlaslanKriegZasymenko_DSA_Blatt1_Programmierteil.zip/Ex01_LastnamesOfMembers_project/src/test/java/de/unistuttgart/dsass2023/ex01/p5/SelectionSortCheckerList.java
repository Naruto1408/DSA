// SOLUTION
package de.unistuttgart.dsass2023.ex01.p5;

public class SelectionSortCheckerList<T extends Comparable<T>> extends AbstractSortCheckerList<T> {

	

}
