package de.unistuttgart.dsass2023.ex01.p5;

import static org.junit.Assert.*;

// START SOLUTION
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
// END SOLUTION

import org.junit.Test;

import de.unistuttgart.dsass2023.ex01.p5.ISimpleList;
import de.unistuttgart.dsass2023.ex01.p5.Sorter;

public class SorterTest {

	

}
