package de.unistuttgart.dsass2023.ex01.p5;

public class Sorter {

	/**
	 * Performs selection sort on provided list, works directly on list object,
	 * hence no return value
	 * 
	 * @param <T>  The type of list element
	 * @param list List to apply the sorting to; unsorted list at first, sorted list
	 *             in the end
	 */
	public static <T extends Comparable<T>> void selectionSort(ISimpleList<T> list) {
		for(int i = 0; i<list.getSize();i++){
			int min_index = i;
			for(int j = i+1; j<list.getSize();j++){
				if(list.getElement(min_index).compareTo(list.getElement(j)) > 0){
					min_index = j;
				}
			}
			list.swapElements(i, min_index);
		}
	}

	/**
	 * Performs insertion sort on provided list, works directly on list object,
	 * hence no return value
	 * 
	 * @param <T>  The type of list element
	 * @param list List to apply the sorting to; unsorted list at first, sorted list
	 *             in the end
	 */
	public static <T extends Comparable<T>> void insertionSort(ISimpleList<T> list) {
		for(int i = 1; i< list.getSize();i++){
			T m = list.getElement(i);
			int j = i;
			while (j>0){
				if(list.getElement(j-1).compareTo(m)<0){
					list.swapElements(j, j-1);
					j = j-1;
				}else {
					break;
				}
			}
			list.swapElements(j,i);
		}
	}

	/**
	 * Performs bubble sort on provided list, works directly on list object, hence
	 * no return value
	 * 
	 * @param <T>  The type of list element
	 * @param list List to apply the sorting to; unsorted list at first, sorted list
	 *             in the end
	 */
	public static <T extends Comparable<T>> void bubbleSort(ISimpleList<T> list) {
		do{
			for(int i = 0; i< list.getSize()-1;i++){
				if(list.getElement(i).compareTo(list.getElement(i+1))>0){
					list.swapElements(i, i+1);
				}
			}
		}while (list.getElement(list.getSize()-2).compareTo(list.getElement(list.getSize()-1))<0);
	}
}
