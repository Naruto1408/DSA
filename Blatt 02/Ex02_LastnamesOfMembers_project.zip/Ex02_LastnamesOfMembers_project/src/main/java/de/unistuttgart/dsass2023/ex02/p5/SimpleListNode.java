package de.unistuttgart.dsass2023.ex02.p5;

public class SimpleListNode<T extends Comparable<T>> implements ISimpleListNode<T>{
	

	@Override
	public T getElement() {

	}

	@Override
	public void setElement(T element) {

	}

	@Override
	public ISimpleListNode<T> getNext() {

	}

	@Override
	public void setNext(ISimpleListNode<T> node) {

	}

}
