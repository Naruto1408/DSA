package de.unistuttgart.dsass2023.ex02.p5;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.*;

public class SimpleListTest {

}
